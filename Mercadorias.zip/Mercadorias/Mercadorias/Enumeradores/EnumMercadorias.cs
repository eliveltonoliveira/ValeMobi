﻿namespace Mercadorias.Enumeradores
{
    public enum MercadoriaStatus
    {
        Nenhum = 0,
        Ativo = 1,
        Inativo = 2
    }

    public enum MercadoriaTipo
    {
        Nenhum = 0,
        Nacional = 1,
        Importado = 2
    }

    public enum TipoNegocio
    {
        Nenhum = 0,
        Compra = 1,
        Venda = 2
    }

}
