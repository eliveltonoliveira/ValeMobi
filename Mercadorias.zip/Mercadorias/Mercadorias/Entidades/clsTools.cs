﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Text;


namespace Mercadorias.Entidades
{
    public class clsTools
    {

        #region Xml

        /// <summary>
        /// Exportar dados da tabela para arquivo xml
        /// </summary>
        /// <param name="dt">Dados</param>
        /// <param name="fileName">Arquivo de Destino</param>
        /// <param name="nomeNoRaiz">Nome do Nó Principal do Xml</param>
        /// <param name="nomeNoLinha">Nome do Nó por Linha</param>
        public static void ExportarXML(DataTable dt, string fileName, string nomeNoRaiz, string nomeNoLinha)
        {
            ExportarXML(dt, fileName, nomeNoRaiz, nomeNoLinha, null);
        }

        /// <summary>
        /// Exportar dados da tabela para arquivo xml
        /// </summary>
        /// <param name="dt">Dados</param>
        /// <param name="fileName">Arquivo de Destino</param>
        /// <param name="nomeNoRaiz">Nome do Nó Principal do Xml</param>
        /// <param name="nomeNoLinha">Nome do Nó por Linha</param>
        /// <param name="encoding">Tipo de Encoding(Padrão Windows-1252)</param>
        public static void ExportarXML(DataTable dt, string fileName, string nomeNoRaiz, string nomeNoLinha, Encoding encoding)
        {
            if (encoding == null)
                encoding = Encoding.GetEncoding("Windows-1252");

            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", fileName));
            HttpContext.Current.Response.ContentEncoding = encoding;
            HttpContext.Current.Response.Charset = "ISO-8859-1";
            HttpContext.Current.Response.Write(GerarXML(dt, nomeNoRaiz, nomeNoLinha, encoding));
            HttpContext.Current.Response.End();
        }

        private static string GerarXML(DataTable dt, string nomeNoRaiz, string nomeNoLinha)
        {
            return GerarXML(dt, nomeNoRaiz, nomeNoLinha, Encoding.GetEncoding("Windows-1252"));
        }

        private static string GerarXML(DataTable dt, string nomeNoRaiz, string nomeNoLinha, Encoding encoding)
        {
            XmlDocument doc = new XmlDocument();
            XmlNode ndDoc = doc.CreateXmlDeclaration("1.0", encoding.HeaderName, null);
            doc.AppendChild(ndDoc);

            XmlNode ndRaiz = doc.CreateElement(nomeNoRaiz);
            doc.AppendChild(ndRaiz);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow row = dt.Rows[i];

                XmlNode ndLinha = doc.CreateElement(nomeNoLinha);
                ndRaiz.AppendChild(ndLinha);

                for (int col = 0; col < dt.Columns.Count; col++)
                {
                    XmlNode ndColuna = doc.CreateElement(dt.Columns[col].ColumnName);
                    ndColuna.AppendChild(doc.CreateTextNode(row[col].ToString()));
                    ndLinha.AppendChild(ndColuna);
                }
            }

            return doc.OuterXml;
        }
        #endregion


        public static void PublicaQtdPagina(DropDownList ddl)
        {
            ddl.Items.Clear();
            ddl.Items.Add(new ListItem("60", "60"));
            ddl.Items.Add(new ListItem("40", "40"));
            ddl.Items.Add(new ListItem("20", "20"));
        }

        public static void PublicaTipoMercadoria(ListControl drop, string TextoZero, string ValorZero)
        {
            drop.Items.Clear();

            if (TextoZero != "" || ValorZero != "")
            {
                drop.Items.Insert(0, new ListItem(TextoZero, ValorZero));
            }

            drop.Items.Add(new ListItem("Nacional", "1"));
            drop.Items.Add(new ListItem("Importado", "2"));
        }

        public static void PublicaTipoNegocio(ListControl drop, string TextoZero, string ValorZero)
        {
            drop.Items.Clear();

            if (TextoZero != "" || ValorZero != "")
            {
                drop.Items.Insert(0, new ListItem(TextoZero, ValorZero));
            }

            drop.Items.Add(new ListItem("Compra", "1"));
            drop.Items.Add(new ListItem("Venda", "2"));
        }


        public static void PublicaStatusMercadoria(ListControl drop, string TextoZero, string ValorZero)
        {
            drop.Items.Clear();

            if (TextoZero != "" || ValorZero != "")
            {
                drop.Items.Insert(0, new ListItem(TextoZero, ValorZero));
            }

            drop.Items.Add(new ListItem("Ativo", "1"));
            drop.Items.Add(new ListItem("Inativo", "2"));
        }


    }
}