﻿using System;
using System.Configuration;
using System.Xml;
using System.Xml.Serialization;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace Mercadorias.Entidades
{
    public class clsConexao
    {

        public clsConexao()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        internal string ConnDados()
        {
            string retorno = System.Configuration.ConfigurationManager.AppSettings["ConnString"];
            
            return retorno;
        }

        public SqlConnection Conexao()
        {
            // ABRE O OBJETO DE CONEXAO
            SqlConnection Conn = new SqlConnection();

            SqlConnection connAux = null;
                      
            if (connAux != null)
            {
                Conn = connAux;

                if (connAux.State != ConnectionState.Open)
                    Conn.Open();
            }
            else
            {
                Conn.ConnectionString = ConnDados();
                Conn.Open();
            }

            return Conn;
        }
    }
}