﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Mercadorias.Enumeradores;

namespace Mercadorias.Entidades
{
    public class clsMercadorias
    {                
        public clsConexao Conn = new clsConexao();
        
        public int ID { get; set; }
        public MercadoriaTipo Tipo { get; set; }
        public string Nome { get; set; }
        public int Quantidade { get; set; }
        public decimal Preco { get; set; }
        public TipoNegocio TipoNegocio { get; set; }
        public MercadoriaStatus Status { get; set; }       
        public string DataInclusao { get; set; }
        public string DataAtualizacao { get; set; }

        public string MensagemErro { get; set; }


        public List<clsMercadorias> Listar()
        {
            List<clsMercadorias> ListaMercadoria = new List<clsMercadorias>();
            clsMercadorias Mercadorias = new clsMercadorias();            
            SqlConnection ConnSQL = Conn.Conexao();

            try
            {  

                SqlCommand oCmd = new SqlCommand("sp_Mercadorias_Listar", ConnSQL);
                oCmd.CommandType = CommandType.StoredProcedure;
                oCmd.Parameters.AddWithValue("@MerCodigo", ID);
                oCmd.Parameters.AddWithValue("@MerTipo", Convert.ToInt32(Tipo));
                oCmd.Parameters.AddWithValue("@MerNome", Nome);             
                oCmd.Parameters.AddWithValue("@TipoNegocio", Convert.ToInt32(TipoNegocio));
                oCmd.Parameters.AddWithValue("@MerStatus", Convert.ToInt32(Status));
                
                SqlDataReader oDataReader = oCmd.ExecuteReader(CommandBehavior.CloseConnection);

                if (oDataReader != null && oDataReader.HasRows)
                {
                    while (oDataReader.Read())
                    {
                        Mercadorias = new clsMercadorias();
                                              
                        Mercadorias.ID = Convert.ToInt32(oDataReader["MerCodigo"]);
                        Mercadorias.Tipo = (MercadoriaTipo)Convert.ToInt32(oDataReader["MerTipo"].ToString());
                        Mercadorias.Nome = oDataReader["MerNome"].ToString().Trim();
                        Mercadorias.Quantidade = Convert.ToInt32(oDataReader["MerQtde"]);
                        Mercadorias.Preco = Convert.ToDecimal(oDataReader["MerPreco"]);                        
                        Mercadorias.TipoNegocio = (TipoNegocio)Convert.ToInt32(oDataReader["TipoNegocio"].ToString());
                        Mercadorias.Status = (MercadoriaStatus)Convert.ToInt32(oDataReader["MerStatus"].ToString());                     
                       
                        ListaMercadoria.Add(Mercadorias);
                    }

                    oDataReader.Close();
                }
               
            }
            catch (Exception err)
            {
                Mercadorias.MensagemErro = err.ToString();
            }
            finally
            {
                if (ConnSQL != null && ConnSQL.State == ConnectionState.Open)
                {
                    ConnSQL.Close();
                }
            }

            return ListaMercadoria;
        }


        public bool Salvar()
        {
            bool retorno = true;
            SqlConnection ConnSQL = Conn.Conexao();
                        
            try
            {
                             
                SqlCommand oCmd = new SqlCommand("SPIKWclsMercadorias_Salvar", ConnSQL);
                oCmd.CommandType = CommandType.StoredProcedure;
                oCmd.Parameters.AddWithValue("@MerCodigo", ID);
                oCmd.Parameters.AddWithValue("@MerTipo", Convert.ToInt32(Tipo));
                oCmd.Parameters.AddWithValue("@MerNome", Nome);
                oCmd.Parameters.AddWithValue("@MerQtde", Quantidade);
                oCmd.Parameters.AddWithValue("@MerPreco", Convert.ToDecimal(Preco));
                oCmd.Parameters.AddWithValue("@TipoNegocio", Convert.ToInt32(TipoNegocio));
                oCmd.Parameters.AddWithValue("@MerStatus", Convert.ToInt32(Status));

                SqlDataReader rs = oCmd.ExecuteReader(CommandBehavior.CloseConnection);

                if (rs.Read())
                {
                    this.ID = Convert.ToInt32(rs["OrcCodigo"].ToString());
                }
                rs.Close();

                retorno = true;
            }
            catch (Exception err)
            {
                MensagemErro = err.ToString();
                retorno = false;
            }
            finally
            {
                if (ConnSQL != null && ConnSQL.State == ConnectionState.Open)
                {
                    ConnSQL.Close();
                }
            }
            return retorno;
        }

        public virtual bool Excluir()
        {
            bool retorno = false;

            clsConexao Conn = new clsConexao();
            SqlConnection ConnSQL = Conn.Conexao();

            try
            {
                SqlCommand scmd = new SqlCommand("sp_Mercadorias_Excluir", ConnSQL);
                scmd.CommandType = CommandType.StoredProcedure;

                scmd.Parameters.AddWithValue("@MerCodigo", ID);
                
                SqlDataReader rs = scmd.ExecuteReader(CommandBehavior.CloseConnection);

                retorno = true;

                rs.Close();
            }
            catch (Exception err)
            {
                throw new Exception(err.ToString());
            }
            finally
            {
                ConnSQL.Close();
            }

            return retorno;
        }

        public bool AlterarStatus()
        {
            bool retorno = false;

            SqlConnection ConnSQL = Conn.Conexao();
            SqlCommand scmd = new SqlCommand("sp_Mercadorias_AlterarStatus", ConnSQL);
            scmd.CommandType = CommandType.StoredProcedure;

            scmd.Parameters.AddWithValue("@MerCodigo", ID);
            scmd.Parameters.AddWithValue("@MerStatus", Convert.ToInt32(Status));
            
            try
            {
                // Atualizacao do status do unidade
                scmd.ExecuteNonQuery();
                retorno = true;
            }
            catch (Exception err)
            {
                this.MensagemErro = err.ToString();
                throw new ArgumentException(err.ToString());
            }
            finally
            {
                ConnSQL.Close();
            }

            return retorno;
        }

    }
}