﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mercadorias.Entidades
{
    public class clsPageBase
    {
        public class PageBase : System.Web.UI.Page
        {

            /// <summary>
            /// Image url
            /// </summary>
            public string IMG { get; set; }

            /// <summary>
            /// Application url
            /// </summary>
            public string URL { get; set; }
            
            /// <summary>
            /// Dir url
            /// </summary>
            public string Dir { get; set; }

            
            public PageBase()
            {
                IMG = System.Configuration.ConfigurationManager.AppSettings["Images"];               
                URL = System.Configuration.ConfigurationManager.AppSettings["URL"];               
                Dir = System.Configuration.ConfigurationManager.AppSettings["Dir"];

                
            }
        }
    }
}