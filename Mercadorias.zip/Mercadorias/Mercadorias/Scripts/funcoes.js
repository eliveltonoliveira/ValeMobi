﻿function MostraLoad() {
    try {
        if (document.getElementById('imgs')) {
            document.getElementById('imgs').style.display = "block";
            document.getElementById('imgs').style.height = getPageSize() + 'px';
            document.getElementById('imgs').style.visibility = "visible";
        }

        if (document.getElementById('click')) {
            document.getElementById('click').style.display = "block";
            document.getElementById('click').style.visibility = "visible";
        }

        combos = document.getElementsByTagName("select");

        for (i = 0; i < combos.length; i++) {
            combos[i].style.visibility = "hidden";
        }
    }
    catch (err) {
        alert(err.description);
    }
}


function MarcarTodos() {
    var $all = jQuery('[id*=hdnSelecionaTodos]');

    checkedByQuery({
        checked: true,
        query: "tbody input[type=checkbox][name*=chkItem]"
    });

    if ($all.length > 0) {
        $all.val("Sim");
    }

    TotalizaChecados(true);
}

function DesmarcarTodos() {
    var $all = jQuery('[id*=hdnSelecionaTodos]');

    checkedByQuery({
        checked: false,
        query: "tbody input[type=checkbox][name*=chkItem]"
    });

    if ($all.length > 0) {
        $all.val("");
    }

    TotalizaChecados();
}

function MarcarVisiveis() {
    var $all = jQuery('[id*=hdnSelecionaTodos]');

    checkedByQuery({
        checked: true,
        query: "tbody input[type=checkbox][name*=chkItem]"
    });

    if ($all.length > 0) {
        $all.val("");
    }

    TotalizaChecados();
}

function DesmarcarVisiveis() {
    var $all = jQuery('[id*=hdnSelecionaTodos]');

    checkedByQuery({
        checked: false,
        query: "tbody input[type=checkbox][name*=chkItem]"
    });

    if ($all.length > 0) {
        $all.val("");
    }

    TotalizaChecados();
}

function TotalizaChecados(todos) {
    var e = window.event || {},
        total = 0,
        $all = jQuery('[id*=hdnSelecionaTodos]'),
        $self = jQuery(this);

    todos = todos || false;

    if (typeof e.target !== 'undefined') {
        $self = jQuery(event.target);
    }

    if ($all.length > 0) {
        if (todos === false && !$self.is(':checked')) {
            $all.val('');
        } else if ($all.val() === "Sim") {
            todos = true;
        }
    }

    total = jQuery("input[type=checkbox][name*=chkItem]:checked").length;

    if (total === 0) {
        todos = false;

        if ($all.length > 0) {
            $all.value = "";
        }
    }

    if (todos) {
        var lblTotalRegistros = GetObj('lblTotalRegistros');
        total = lblTotalRegistros.innerHTML;
    }

    if (document.getElementById("totalSelecionados")) {
        document.getElementById("totalSelecionados").innerHTML = Trim(total.toString());
    }
}

function Acoes(textoAviso) {
    try {
        var ddlAcoes = GetObj('ddlAcoes');
        var SelecionaTodos = GetObj('hdnSelecionaTodos');

        if (ddlAcoes) {
            var TodosRegistros = "";
            var ItensCodigos = "";

            if (SelecionaTodos) {
                TodosRegistros = SelecionaTodos.value;
            }

            if (TodosRegistros != "Sim") {
                jQuery("input[type=checkbox][name*=chkItem]:checked").each(function () {
                    ItensCodigos = (ItensCodigos == "" ? this.value : ItensCodigos + ";" + this.value);
                });

                var ItensSelecionados = GetObj('hdnItensSelecionados');
                ItensSelecionados.value = ItensCodigos;
            }

            if (TodosRegistros != "" || ItensCodigos != "") {
                if (ddlAcoes.value == "XML" || ddlAcoes.value == "Excel") {
                    MostraLoad();
                    Pesquisar();
                }
                else {
                    EscolheAcao(ddlAcoes.value);
                }
            }
            else {
                ddlAcoes.value = "";
                OcultaLoad();
                MostraErro("Escolha no mínimo " + textoAviso + " para esta ação!");
            }
        }
    }
    catch (err) {
        OcultaLoad();
        MostraErro(err.Message);
    }
}
