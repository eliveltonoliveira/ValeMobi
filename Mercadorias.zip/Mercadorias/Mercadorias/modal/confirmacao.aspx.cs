﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mercadorias.modal
{
    public partial class confirmacao : System.Web.UI.Page
    {
        #region Atributos

        protected string Mensagem = string.Empty;
        protected string FuncaoConfirma = string.Empty;
        protected string FuncaoCancela = string.Empty;

        #endregion

        #region Eventos

        protected void Page_Load(object sender, EventArgs e)
        {
            CarregaParametros();
        }

        #endregion

        #region Metodos

        private void CarregaParametros()
        {
            try
            {
                if (HttpContext.Current.Request.QueryString["tipo"] != null)
                {
                    string tipo = HttpContext.Current.Request.QueryString["tipo"];
                    string valores = HttpContext.Current.Request.QueryString["valores"];

                    switch (tipo)
                    {
                        case "excluirMercadoria":
                            this.Mensagem = "Tem certeza de que deseja excluir as mercadorias selecionadas?";
                            this.FuncaoConfirma = "ExcluirMercadoria('" + HttpContext.Current.Request.QueryString["Codigo"].ToString() + "')";
                            this.FuncaoCancela = "CancelaAcao()";
                            break;
                        case "ativarMercadoria":
                            this.Mensagem = "Tem certeza de que deseja ativar as mercadorias selecionadas?";
                            this.FuncaoConfirma = "Pesquisar()";
                            this.FuncaoCancela = "CancelaAcao()";
                            break;
                        case "inativarMercadoria":
                            this.Mensagem = "Tem certeza de que deseja inativar as mercadorias selecionadas?";
                            this.FuncaoConfirma = "Pesquisar()";
                            this.FuncaoCancela = "CancelaAcao()";
                            break;                      
                        default:
                            break;
                       
                    }
                }
            }
            catch
            {
            }
        }

        #endregion
    }
}