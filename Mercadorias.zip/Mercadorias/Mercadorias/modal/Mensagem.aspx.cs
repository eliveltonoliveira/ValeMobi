﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mercadorias.modal
{
    public partial class Mensagem : System.Web.UI.Page
    {     

        public string IMG = System.Configuration.ConfigurationManager.AppSettings["Images"];               
        public string URL = System.Configuration.ConfigurationManager.AppSettings["URL"];

        protected string MENSAGEM = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            hplProsseguir.Attributes.Add("rel", "modalclose");

            if (Request.QueryString.Get("m") != null && Request.QueryString.Get("m").Trim() != "")
            {
                this.MENSAGEM = Request.QueryString.Get("m").Trim();

                if (Request.QueryString.Get("d") != null && Request.QueryString.Get("d") != "")
                {
                    if (Request.QueryString.Get("tipoArquivo") != null && Request.QueryString.Get("tipoArquivo") != "")
                    {
                        this.MENSAGEM = Request.QueryString.Get("m").Replace("clique aqui", "<a href=\"" + URL + "/modal/Download.aspx?f=" + Request.QueryString.Get("d") + "&tipoArquivo=" + Request.QueryString.Get("tipoArquivo") + "\">clique aqui</a>");
                    }
                }

                if (Request.QueryString.Get("f") != null && Request.QueryString.Get("f") != "")
                {
                    this.ClientScript.RegisterStartupScript(this.GetType(), "Pesquisa", "window.setTimeout(function(){" + Request.QueryString.Get("f") + ";}, 3000);", true);
                }

                if (Request.QueryString.Get("ab") != null && Request.QueryString.Get("ab") != string.Empty)
                {
                    hplProsseguir.Attributes.Add("onclick", Request.QueryString.Get("ab"));
                }
            }
        }
    }
}