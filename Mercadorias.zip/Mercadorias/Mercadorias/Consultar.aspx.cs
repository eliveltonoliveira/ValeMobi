﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;

using Mercadorias.Entidades;
using Mercadorias.Enumeradores;

namespace Mercadorias
{
    public partial class _Default : System.Web.UI.Page
    {

        public string URL = System.Configuration.ConfigurationManager.AppSettings["URL"];
        public string IMG = System.Configuration.ConfigurationManager.AppSettings["Images"];

        private bool PesquisaPorStatus = false;
                
        protected void Page_Load(object sender, EventArgs e)
        {                   
                CarregaDados();
         
        }

        private void CarregaDados()
        {
            if (!IsPostBack)
            {
                if (Session["AvisoOKListagem"] != null && Session["AvisoOKListagem"].ToString() != "")
                {
                    this.ClientScript.RegisterStartupScript(this.GetType(), "Mensagem", "$(document).ready(function(){closeModal();openModal('" + URL + "/modal/Mensagem.aspx?m=' + encodeURIComponent('" + Session["AvisoOKListagem"].ToString() + "'));});", true);
                    Session.Remove("AvisoOKListagem");
                }

                if (Session["Codigo"] != null && Session["Codigo"].ToString() != "")
                    Session.Remove("Codigo");

                clsTools.PublicaQtdPagina(this.ddlQtdPagina);
                clsTools.PublicaTipoMercadoria(this.ddlTipo, "Nenhum", "0");
                clsTools.PublicaTipoNegocio(this.ddlTipoNegocio, "Nenhum", "0");
                clsTools.PublicaStatusMercadoria(this.ddlStatus, "Nenhum", "0");
                               
            }

            this.ClientScript.RegisterStartupScript(GetType(), "TrataChecados", "TotalizaChecados();", true);
        }

        protected void btnPesquisar_Click(object sender, System.EventArgs e)
        {
            this.litNome.Text = this.litNome.Text != string.Empty ? this.litNome.Text : " --- ";

            clsMercadorias Mercadoria = new clsMercadorias();
            Mercadoria.Nome         = this.txtNome.Text;
            Mercadoria.Tipo          = (MercadoriaTipo)this.ddlTipo.SelectedIndex;            
            Mercadoria.Status        = (MercadoriaStatus)Convert.ToInt32(this.ddlStatus.SelectedValue);
            
            if(!String.IsNullOrEmpty(this.txtNumero.Text))
                Mercadoria.ID            = Convert.ToInt32(this.txtNumero.Text);    

            clsMercadorias MercadoriaSelect = new clsMercadorias();
            List<clsMercadorias> aMercadoria = Mercadoria.Listar();

             if (aMercadoria.Count > 0)
            {               
                this.divConsulta.Style.Add("display", "none");
                this.divResultado.Style.Add("display", "");

                int ItensPagina = Convert.ToInt32(this.ddlQtdPagina.SelectedValue.ToString());
                int PaginaAtual = Convert.ToInt32(this.txtPaginaAtual.Text);

                DataTable dtMercadoria = new DataTable("dtMercadoria");

                dtMercadoria.Columns.Add("Codigo", typeof(int));
                dtMercadoria.Columns.Add("Nome", typeof(string));                               
                dtMercadoria.Columns.Add("Tipo", typeof(string));
                dtMercadoria.Columns.Add("TipoNegocio", typeof(string));  
                dtMercadoria.Columns.Add("Status", typeof(string));                

                for (int i = 0; i < aMercadoria.Count; i++)
                {
                    MercadoriaSelect = (clsMercadorias)aMercadoria[i];
                                      
                    DataRow drMercadoria = dtMercadoria.NewRow();
                    drMercadoria["Codigo"] = MercadoriaSelect.ID.ToString();
                    drMercadoria["Nome"] = MercadoriaSelect.Nome;
                    drMercadoria["Tipo"] = Convert.ToString((MercadoriaTipo)Convert.ToInt32(MercadoriaSelect.Tipo));
                    drMercadoria["TipoNegocio"] = Convert.ToString((TipoNegocio)Convert.ToInt32(MercadoriaSelect.Tipo));
                    drMercadoria["Status"] = Convert.ToString((MercadoriaStatus)Convert.ToInt32(MercadoriaSelect.Status));                    
                    dtMercadoria.Rows.Add(drMercadoria);
                }

                DataView dvMercadoria = new DataView(dtMercadoria);
                dvMercadoria.Sort = this.hdnSort.Value.Trim() + " " + this.hdnOrdem.Value.Trim();

                dtMercadoria = dvMercadoria.ToTable();

                if (this.ddlAcoes.SelectedValue == "")
                {
                    PagedDataSource pdsMercadoria   = new PagedDataSource();
                    pdsMercadoria.DataSource         = dtMercadoria.DefaultView;
                    pdsMercadoria.AllowPaging        = true;
                    pdsMercadoria.PageSize           = ItensPagina;
                    pdsMercadoria.CurrentPageIndex   = PaginaAtual - 1;

                    this.hdnPaginaQtdeMax.Value     = pdsMercadoria.PageCount.ToString();
                    this.txtPaginaAtual.Text        = PaginaAtual.ToString();
                    this.lblQtdPaginas.Text         = pdsMercadoria.PageCount.ToString();

                    this.lblTotalRegistros.Text = aMercadoria.Count.ToString();

                    this.rpMercadoria.DataSource = pdsMercadoria;
                    this.rpMercadoria.DataBind();
                }

                #region XML
                else if (this.ddlAcoes.SelectedValue == "XML")
                {
                    bool TodosResultados = false;

                    if (this.hdnSelecionaTodos.Value.ToLower() == "sim")
                    {
                        TodosResultados = true;
                    }

                    ArrayList aMercadoriaSelecionados = new ArrayList();

                    if (!TodosResultados && this.hdnItensSelecionados.Value.Trim() != "")
                    {
                        if (this.hdnItensSelecionados.Value.Trim().IndexOf(';') > -1)
                        {
                            string[] MercadoriasSelecionados = this.hdnItensSelecionados.Value.Trim().Split(';');

                            for (int i = 0; i < MercadoriasSelecionados.Length; i++)
                            {
                                aMercadoriaSelecionados.Add(MercadoriasSelecionados[i].ToString().Trim());
                            }
                        }
                        else
                        {
                            aMercadoriaSelecionados.Add(this.hdnItensSelecionados.Value.ToString().Trim());
                        }
                    }
                 
                    DataTable dtRegXML = new DataTable("Mercadoria");
                    dtRegXML.Columns.Add("Codigo", typeof(int));
                    dtRegXML.Columns.Add("Nome", typeof(string));                   
                    dtRegXML.Columns.Add("Tipo", typeof(string));
                    dtRegXML.Columns.Add("TipoNegocio", typeof(string));
                    dtRegXML.Columns.Add("Status", typeof(string)); 
                                      
                    DataRow rowXML;

                    for (int i = 0; i < dtMercadoria.Rows.Count; i++)
                    {
                        DataRow linha = (DataRow)dtMercadoria.Rows[i];

                        if (TodosResultados || aMercadoriaSelecionados.Contains(linha["Codigo"].ToString().Trim()))
                        {
                            clsMercadorias MercadoriaAux = new clsMercadorias();
                            MercadoriaAux.ID = Convert.ToInt32(linha["Codigo"].ToString().Trim());

                            var aUnidadeAux = MercadoriaAux.Listar();
                            if (aUnidadeAux.Count == 1)
                            {
                                MercadoriaAux = (clsMercadorias)aUnidadeAux[0];
                                rowXML = dtRegXML.NewRow();
                                rowXML["Codigo"] = MercadoriaSelect.ID.ToString();
                                rowXML["Nome"] = MercadoriaSelect.Nome;                                                                
                                rowXML["Tipo"] = Convert.ToString((MercadoriaTipo)Convert.ToInt32(MercadoriaSelect.Tipo));
                                rowXML["TipoNegocio"] = Convert.ToString((TipoNegocio)Convert.ToInt32(MercadoriaSelect.TipoNegocio));
                                rowXML["Status"] = MercadoriaSelect.Status.ToString();                             
                                dtRegXML.Rows.Add(rowXML);
                            }
                        }
                    }

                    clsTools.ExportarXML(dtRegXML, "Mercadoria.xml", "Mercadorias", "Mercadoria");
                }
                #endregion

                #region Excel
                else if (this.ddlAcoes.SelectedValue == "Excel")
                {
                    bool TodosResultados = false;

                    if (this.hdnSelecionaTodos.Value.ToLower() == "sim")
                    {
                        TodosResultados = true;
                    }

                    ArrayList aUnidadesSelecionadas = new ArrayList();

                    if (!TodosResultados && this.hdnItensSelecionados.Value.Trim() != "")
                    {
                        if (this.hdnItensSelecionados.Value.Trim().IndexOf(';') > -1)
                        {
                            string[] UnidadesSelecionadas = this.hdnItensSelecionados.Value.Trim().Split(';');

                            for (int i = 0; i < UnidadesSelecionadas.Length; i++)
                            {
                                aUnidadesSelecionadas.Add(UnidadesSelecionadas[i].ToString().Trim());
                            }
                        }
                        else
                        {
                            aUnidadesSelecionadas.Add(this.hdnItensSelecionados.Value.ToString().Trim());
                        }
                    }
                           
                    DataTable dtRegExcel = new DataTable("Mercadoria");
                    dtRegExcel.Columns.Add("Codigo", typeof(int));
                    dtRegExcel.Columns.Add("Nome", typeof(string));
                    dtRegExcel.Columns.Add("Tipo", typeof(string));
                    dtRegExcel.Columns.Add("TipoNegocio", typeof(string));
                    dtRegExcel.Columns.Add("Status", typeof(string)); 

                                     
                    DataRow rowExcel;

                    for (int i = 0; i < dtMercadoria.Rows.Count; i++)
                    {
                        DataRow linha = (DataRow)dtMercadoria.Rows[i];

                        if (TodosResultados || aUnidadesSelecionadas.Contains(linha["Codigo"].ToString().Trim()))
                        {
                            clsMercadorias MercadoriaAux = new clsMercadorias();
                            MercadoriaAux.ID = Convert.ToInt32(linha["Codigo"].ToString().Trim());

                            var aUnidadeAux = MercadoriaAux.Listar();
                            if (aUnidadeAux.Count == 1)
                            {
                                MercadoriaAux = (clsMercadorias)aUnidadeAux[0];

                                rowExcel = dtRegExcel.NewRow();
                                rowExcel["Codigo"] = MercadoriaSelect.ID.ToString();
                                rowExcel["Nome"] = MercadoriaSelect.Nome;
                                rowExcel["Tipo"] = Convert.ToString((MercadoriaTipo)Convert.ToInt32(MercadoriaSelect.Tipo));
                                rowExcel["TipoNegocio"] = Convert.ToString((TipoNegocio)Convert.ToInt32(MercadoriaSelect.TipoNegocio));
                                rowExcel["Status"] = MercadoriaSelect.Status.ToString(); 
                                dtRegExcel.Rows.Add(rowExcel);
                            }
                        }
                    }

                    //clsTools.ExportarExcel(dtRegExcel, "Mercadorias.xls");
                }
                #endregion

                #region Excluir
                else if (this.ddlAcoes.SelectedValue == "Excluir")
                {
                    bool TodosResultados = false;

                    if (this.hdnSelecionaTodos.Value.ToLower() == "sim")
                    {
                        TodosResultados = true;
                    }

                    ArrayList aMercadoriaSelecionados = new ArrayList();

                    if (!TodosResultados && this.hdnItensSelecionados.Value.Trim() != "")
                    {
                        if (this.hdnItensSelecionados.Value.Trim().IndexOf(';') > -1)
                        {
                            string[] MercadoriaSelecionados = this.hdnItensSelecionados.Value.Trim().Split(';');

                            for (int i = 0; i < MercadoriaSelecionados.Length; i++)
                            {
                                aMercadoriaSelecionados.Add(MercadoriaSelecionados[i].ToString().Trim());
                            }
                        }
                        else
                        {
                            aMercadoriaSelecionados.Add(this.hdnItensSelecionados.Value.ToString().Trim());
                        }
                    }

                    bool erro = false;

                    for (int i = 0; i < dtMercadoria.Rows.Count; i++)
                    {
                        DataRow linha = (DataRow)dtMercadoria.Rows[i];

                        if (TodosResultados || aMercadoriaSelecionados.Contains(linha["Codigo"].ToString().Trim()))
                        {
                            clsMercadorias oMercadoriaExcluir = new clsMercadorias();
                            oMercadoriaExcluir.ID = Convert.ToInt32(linha["Codigo"].ToString().Trim());

                            var aOrcAux = oMercadoriaExcluir.Listar();
                            if (aOrcAux.Count == 1)
                            {
                                oMercadoriaExcluir = (clsMercadorias)aOrcAux[0];

                                if (!oMercadoriaExcluir.Excluir())
                                {
                                    erro = true;
                                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Erro", "openModal('" + URL + "/modal/erro.aspx?e=' + encodeURIComponent('Erro ao excluir mercadorias!'));", true);
                                    break;
                                }
                            }
                        }
                    }

                    this.ddlAcoes.SelectedValue = "";
                    this.hdnSelecionaTodos.Value = "";

                    if (!erro)
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Ok", "openModal('" + URL + "/modal/mensagem.aspx?m=' + encodeURIComponent('mercadorias excluídos com sucesso.'));", true);                        
                        this.txtPaginaAtual.Text = "1";
                        this.btnPesquisar_Click(this.btnPesquisar, new EventArgs());
                    }
                }
                #endregion
            }
            else
            {
                this.divConsulta.Style.Add("display", "");
                this.divResultado.Style.Add("display", "none");

                if (!PesquisaPorStatus)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Erro", "openModal('" + URL + "/modal/Erro.aspx?e=' + encodeURIComponent('Nenhum mercadoria encontrado." + MercadoriaSelect.MensagemErro + "'));", true);
                }
            }
        }

        protected void rpMercadoria_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataRowView row = (DataRowView)e.Item.DataItem;
                
                
                // Campo Código
                ((Literal)e.Item.FindControl("litCodigo")).Text = row["Codigo"].ToString();

                // Campo Nome
                ((Literal)e.Item.FindControl("litNome")).Text = row["Nome"].ToString();
                               
                // Campo Tipo
                ((Literal)e.Item.FindControl("litTipo")).Text = row["Tipo"].ToString();

                // Campo Tipo Negocio
                ((Literal)e.Item.FindControl("litTipoNegocio")).Text = row["TipoNegocio"].ToString();


                // Campo Status
                ((Literal)e.Item.FindControl("litStatus")).Text = row["Status"].ToString();

              
              
                    ((HyperLink)e.Item.FindControl("lnkEditar")).Attributes.Add("onclick", "Editar('" + row["Codigo"].ToString() + "');");
                    ((Image)e.Item.FindControl("imgEditar")).ImageUrl = IMG + "/ico_editar.gif";
              
                    ((HyperLink)e.Item.FindControl("lnkExcluir")).Attributes.Add("onclick", "Excluir('" + row["Codigo"].ToString() + "');");
                    ((Image)e.Item.FindControl("imgExcluir")).ImageUrl = IMG + "/icon_excluir.gif";
               
            }
        }

      
        # region AJAX
        [WebMethod]
        public static string[] Editar(string CodigoMercadoria)
        {
            string[] retorno = new string[2];

            if (HttpContext.Current.Session["Sessao"] != null)
            {
                HttpContext.Current.Session.Add("Codigo", CodigoMercadoria);

                retorno[0] = "1";
                retorno[1] =  "/Mercadoria/inserir.aspx?codigo=" + CodigoMercadoria;
            }
            else
            {
                retorno[0] = "2";
                retorno[1] = "Sessão expirada, faça seu login novamente.";
            }

            return retorno;
        }

        [WebMethod]
        public static string[] ExcluirMercadoria(string Codigo)
        {
            string[] retorno = new string[2];

            if (HttpContext.Current.Session["Sessao"] != null)
            {
                clsMercadorias Mercadoria = new clsMercadorias();
                Mercadoria.ID = Convert.ToInt32(Codigo);

                var aMercadoriaExcluir = Mercadoria.Listar();

                if (aMercadoriaExcluir.Count == 1)
                {
                    clsMercadorias oMercadoriaExcluir = (clsMercadorias)aMercadoriaExcluir[0];

                    if (oMercadoriaExcluir.Excluir())
                    {
                        retorno[0] = "1";
                        retorno[1] = "mercadoria excluída com sucesso.";
                    }
                    else
                    {
                        retorno[0] = "0";
                        retorno[1] = "Não foi possível excluir a mercadoria!";
                    }
                }
            }
            else
            {
                retorno[0] = "2";
                retorno[1] = "Sessão expirada, faça seu login novamente.";
            }

            return retorno;
        }
               
        # endregion
    }

}
