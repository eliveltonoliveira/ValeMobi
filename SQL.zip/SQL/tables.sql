IF(NOT EXISTS(SELECT * 
				FROM SYSOBJECTS 
			   WHERE XTYPE = 'U'
				 AND NAME = 'tbl_Mercadorias'))
BEGIN

CREATE TABLE [dbo].[tbl_Mercadorias](
	[MerCodigo] [int] IDENTITY(1,1) NOT NULL,
	[MerTipo] [int] NOT NULL,	
	[MerNome] [varchar](7000) NOT NULL,	
	[MerQtde] [int] NOT NULL,
	[MerPreco] [decimal] NOT NULL,
	[TipoNegocio] [int] NOT NULL,
	[MerStatus] [int] NOT NULL,	
	[MerDtAlteracao] [datetime] NOT NULL,
	[MerInclusao] [datetime] NOT NULL,
	[MerExcluido] [bit] NOT NULL,	
 CONSTRAINT [PK_tbl_Mercadorias] PRIMARY KEY CLUSTERED 
(
	[MerCodigo] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
