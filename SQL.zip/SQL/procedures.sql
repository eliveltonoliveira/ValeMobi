
IF EXISTS(SELECT * FROM sysobjects WHERE xtype = 'P' AND name = 'sp_Mercadorias_Salvar')
    DROP PROCEDURE sp_Mercadorias_Salvar
GO


-- ##############################################################################
-- # NOME		: sp_Mercadorias_Listar
-- # DEVELOPER	: 
-- # COPYRIGHT	: 
-- ##############################################################################
-- ##############################################################################
-- # HIST�RICO
-- # 22/01/2017	: Cria��o e In�cio de Implementa��o
-- ##############################################################################

CREATE PROCEDURE [dbo].[sp_Mercadorias_Salvar] (
	@MerCodigo			as  int					=  0,	
	@MerTipo		    as  int					=  0,
	@MerNome			as  [varchar](7000) 	=  '',				
	@MerQtde			as  int					=  0,				
	@MerPreco			as  decimal				=  '',				
	@TipoNegocio		as  int					=  0,
	@MerStatus			as  int					=  0					
) AS

BEGIN
	SET NOCOUNT ON

	-- INCLUS�O
	IF(@MerCodigo = 0)
	BEGIN
		INSERT INTO tbl_Mercadorias
			(				 
				MerTipo, 		
				MerNome,
				MerQtde,
				MerPreco,
				TipoNegocio,								
				MerStatus,			
				MerDtAlteracao,	
				MerDtInclusao				
			)
			VALUES
			(
				@MerTipo, 		
				@MerNome,
				@MerQtde,
				@MerPreco,
				@TipoNegocio,		
				@MerStatus,			
				GetDate(),
				GetDate()				
			);
		
		SELECT @MerCodigo = SCOPE_IDENTITY();
	END
	ELSE 
	BEGIN
		-- ALTERA��O 
		IF(@MerCodigo > 0)
		BEGIN
			
			UPDATE tbl_Mercadorias SET
				MerTipo			= @MerTipo, 		
				MerNome			= @MerNome,
				MerQtde			= @MerQtde,
				MerPreco		= @MerPreco,
				TipoNegocio		= @TipoNegocio,		
				MerStatus		= @MerStatus,	
			 	MerDtAlteracao	= GetDate()
			WHERE
				MerCodigo		= @MerCodigo
			
			
			SELECT 
				MerCodigo,
				MerTipo,			
				MerNome,
				convert(varchar, MerDtAlteracao, 121) [MerDtAlteracao]				
			FROM 
				tbl_Mercadorias (nolock)
			WHERE
				MerCodigo = @MerCodigo
		END
	END


	SET NOCOUNT OFF
END


GO




IF EXISTS(SELECT * FROM sysobjects WHERE xtype = 'P' AND name = 'sp_Mercadorias_Listar')
    DROP PROCEDURE sp_Mercadorias_Listar
GO

-- ##############################################################################
-- # NOME		: sp_Mercadorias_Listar
-- # DEVELOPER	: 
-- # COPYRIGHT	: 
-- ##############################################################################
-- ##############################################################################
-- # HIST�RICO
-- # 22/01/2017	: Cria��o e In�cio de Implementa��o
-- ##############################################################################

CREATE PROCEDURE [dbo].[sp_Mercadorias_Listar] (
	@MerCodigo			as  int					=  0,	
	@MerTipo		    as  int					=  0,
	@MerNome			as  [varchar](7000) 	=  '',								
	@TipoNegocio		as  int					=  0,
	@MerStatus			as  int					=  0	
) AS


BEGIN
	SET NOCOUNT ON

	SELECT 
		MerCodigo,		
		MerTipo, 		
		MerNome,
		MerQtde,
		MerPreco,
		TipoNegocio,								
		MerStatus,					
		convert(varchar, MerDtAlteracao, 121) [MerDtAlteracao],	
		convert(varchar, MerDtInclusao, 121) [MerDtInclusao]		
	FROM 
		tbl_Mercadorias (nolock)
	WHERE
		MerExcluido = 0
		AND	(MerCodigo = @MerCodigo OR @MerCodigo = 0)
		AND	(MerTipo = @MerTipo OR @MerTipo = 0)
		AND (MerNome Like '%' + @MerNome + '%' OR @MerNome = '')
		AND (TipoNegocio = @TipoNegocio OR @TipoNegocio = 0)
		AND (MerStatus = @MerStatus OR @MerStatus = 0)		

	SET NOCOUNT OFF
END

GO


  
IF EXISTS(SELECT * FROM sysobjects WHERE xtype = 'P' AND name = 'sp_Mercadorias_Excluir')
    DROP PROCEDURE sp_Mercadorias_Excluir
GO
    
-- ##############################################################################
-- # NOME		: sp_Mercadorias_Excluir
-- # DEVELOPER	: 
-- # COPYRIGHT	: 
-- ##############################################################################
-- ##############################################################################
-- # HIST�RICO
-- # 22/01/2017	: Cria��o e In�cio de Implementa��o
-- ##############################################################################

CREATE PROCEDURE [dbo].[sp_Mercadorias_Excluir] (  
 @MerCodigo as  int		=  0
 
) AS  
  
BEGIN  
 SET NOCOUNT ON  
  
 UPDATE tbl_Mercadorias SET  
  MerExcluido = 1, 
  MerDtAlteracao = GETDATE()
 WHERE  
   MerCodigo = @MerCodigo  
 
  
 SET NOCOUNT OFF  
END  
  
  
GO

IF EXISTS(SELECT * FROM sysobjects WHERE xtype = 'P' AND name = 'sp_Mercadorias_AlterarStatus')
    DROP PROCEDURE sp_Mercadorias_AlterarStatus
GO
  
-- ##############################################################################
-- # NOME		: sp_Mercadorias_AlterarStatus
-- # DEVELOPER	: 
-- # COPYRIGHT	: 
-- ##############################################################################
-- ##############################################################################
-- # HIST�RICO
-- # 22/01/2017	: Cria��o e In�cio de Implementa��o
-- ##############################################################################

CREATE PROCEDURE [dbo].[sp_Mercadorias_AlterarStatus] (  
 @MerCodigo  as  int		=  0,
 @MerStatus	 as	int			= 0,  
 
) AS  
  
BEGIN  
 SET NOCOUNT ON  
  
 UPDATE tbl_Mercadorias SET  
	MerStatus = @MerStatus, 
	MerDtAlteracao = GETDATE()
 WHERE  
	MerCodigo = @MerCodigo  
 
 SET NOCOUNT OFF  
END  
  
  
GO